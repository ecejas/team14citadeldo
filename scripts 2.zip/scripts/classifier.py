import numpy as np
import pandas as pd

import data
x = np.genfromtxt("./Features.csv", delimiter=",")
y = np.genfromtxt("./labels.csv", delimiter=",")

xTr = x[:202513]
yTr = y[:202513]
xTe = x[202513:]
yTe = y[202513:]

#SVM
from sklearn.svm import SVC
svm_clf = SVC(kernel="linear", C=1.0, gamma="auto")
svm_clf.fit(xTr, yTr)

#random forest
from sklearn.ensemble import RandomForestClassifier
rf.clf = RandomForestClassifier(n_estimators=15)
rf.clf.fit(xTr, yTr)

#neural nets
from sklearn.neural_network import MLPClassifier
clf = MLPClassifier(
    solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(5, 2), random_state=1)
nn_clf.fit(xTr, yTr)

svm_preds = svm_clf.predict(xTe)

rf_preds = rf_clf.predict(xTe)

nn_preds = nn_clf.predict(xTe)