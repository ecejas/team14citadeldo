import pandas as pd


def load_data(file_path):
    """Load a csv file."""
    data = pd.read_csv(file_path)
    data = data.fillna(0)
    data = data.loc[data['year'] == 2017]
    airports = ['JFK', 'EWR', 'LGA']
    data = data.loc[data['destination_airport'].isin(airports)]
    data = data[[
        'destination_airport', 'airline_id', 'actual_departure', 'taxi_out',
        'scheduled_arrival', 'distance'
    ]]
    data.to_csv('/Users/ganesh/Desktop/Features.csv')


def main():
    file_path = "/Users/ganesh/Desktop/Datasets/flight_traffic.csv"
    load_data(file_path)


if __name__ == '__main__':
    main()