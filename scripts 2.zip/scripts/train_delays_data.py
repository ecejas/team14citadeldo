#!/usr/bin/env python3
import pandas as pd


def load_data(file_path):
    data = pd.read_csv(file_path)
    data = data.fillna(0)
    return data


def parse_to_mins(str_float):
    return int(str_float[:2]) * 60 + int(str_float[2:])


def assign_labels(data, airports):
    data = data.loc[data['destination_airport'].isin(airports)]
    labels = []
    count = 0
    for index, row in data.iterrows():
        expected = str(row['scheduled_arrival'])
        actual = str(row['actual_arrival'])
        if actual == '' or expected == '':
            # ignore canceled flights.
            labels.append(-1)
            continue

        # remove .0
        actual = actual[:-2]

        # For when the input data is 8.9 or 45
        if len(actual) != 4:
            actual = actual.zfill(4)
        if len(expected) != 4:
            expected = expected.zfill(4)

        expected_mins = parse_to_mins(expected)
        actual_mins = parse_to_mins(actual)

        # ignore flights ontime.
        if actual_mins <= expected_mins:
            labels.append(-1)
            continue
        if abs(actual_mins - expected_mins) < 30:
            labels.append(0)
        elif abs(actual_mins - expected_mins) < 90:
            labels.append(1)
        elif abs(actual_mins - expected_mins) < 150:
            labels.append(2)
        else:
            labels.append(3)

    data['labels'] = labels
    data.to_csv('delays_train_data.csv')


if __name__ == '__main__':
    file_path = "~/Desktop/flight_traffic.csv"
    data = load_data(file_path)
    assign_labels(data, ['JFK', 'EWR', 'LGA'])